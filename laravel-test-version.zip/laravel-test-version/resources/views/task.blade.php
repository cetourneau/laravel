@extends('layouts/layout')
@section('title', 'List of Tasks')
@section ('main')
<div class='task-list'>
    <h2>{{$task->title}}</h2>
    <p>{{$task->created_at}}</p>
    <p>{{$task->description}}</p>
</div>
@endsection

<?php
namespace Carbon;

class Carbon extends \DateTime
{
    $date = Carbon::now()->locale('fr_FR');

    echo $date->locale();            // fr_FR
    echo "\n";
    echo $date->isoFormat('LLLL');   // mardi 3 mai 2022 11:44
    }